import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.Dashboard;
import pages.LoginPage;
import pages.Reports;

import java.io.File;
import java.sql.Time;
import java.util.concurrent.TimeUnit;


public class Login {

    static WebDriver driver;
    static ExtentTest test;
    static ExtentReports report;
    static LoginPage login;
    static Dashboard dashboard;
    static Reports reportPageObject;

    public static void main(String[] args) throws ClassNotFoundException, InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\chromedriver_win32(1)\\chromedriver.exe");
        driver = new ChromeDriver();
        login = new LoginPage(driver);
        dashboard = new Dashboard(driver);
        reportPageObject= new Reports(driver);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        startTest();
        checkLoginWithValidCredentials();
        //checkLoginWithValidUserInvalidPassword();
        //checkLoginWithInValidUserValidPassword();
        //checkLoginWithInValidUserInvalidPassword();
        //checkUpperCase();
        //checkLowerCase();
        //checkUpperLowerCase();
        checkChatHistoryReport();
        checkOfflineMessageReport();
        checkMissedChatsReport();
        checkBotHistoryReport();
        checkBotAnalyticsReport();
        checkBotLeadReport();
        endTest();
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public static void startTest() {
        String var10000 = System.getProperty("user.dir");
        String filePath = var10000 + File.separator + "ExtentReports" + File.separator + "AutomationTestReport.html";
        report = new ExtentReports(filePath);
        test = report.startTest("ReveChat-Automation-Test");
        driver.get("https://test-chat-02.revechat.com/");
        driver.manage().window().maximize();
    }

    public static void checkLoginWithValidCredentials() throws InterruptedException {
        login.clickLoginWithValidCredentials();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if (dashboard.getHeading().toString().equalsIgnoreCase("What's New"))
            test.log(LogStatus.PASS, "TC 1-Login with valid Email & valid Password: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 1-Login with valid Email & valid Password: FAILED");

        //dashboard.clickLogout();
    }

    public static void checkLoginWithValidUserInvalidPassword() throws InterruptedException {
        login.clickLoginWithValidUserInvalidPassword();
        Thread.sleep(1000);
        if (login.getLoginErrorMessage().toString().equalsIgnoreCase("Email address or password does not match"))
            test.log(LogStatus.PASS, "TC 2-Login with valid Email & Invalid Password: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 2-Login with valid Email & Invalid Password: FAILED");
    }

    public static void checkLoginWithInValidUserValidPassword() throws InterruptedException {
        login.clickLoginWithInValidUserValidPassword();
        Thread.sleep(1000);
        if (login.getLoginErrorMessage().toString().equalsIgnoreCase("Email address or password does not match"))
            test.log(LogStatus.PASS, "TC 3-Login with Invalid Email & valid Password: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 3-Login with Invalid Email & valid Password: FAILED");
    }

    public static void checkLoginWithInValidUserInvalidPassword() throws InterruptedException {
        login.clickLoginWithInValidUserInvalidPassword();
        Thread.sleep(1000);
        if (login.getLoginErrorMessage().toString().equalsIgnoreCase("Email address or password does not match"))
            test.log(LogStatus.PASS, "TC 4-Login with valid InEmail & Invalid Password: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 4-Login with valid InEmail & Invalid Password: FAILED");
    }

    public static void checkUpperCase() throws InterruptedException {
        login.clickUpperCase();
        Thread.sleep(1000);
        if (dashboard.getHeading().toString().equalsIgnoreCase("What's New"))
            test.log(LogStatus.PASS, "TC 5-Login with username in Upper Case: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 5-Login with username in Upper Case: FAILED");
        dashboard.clickLogout();
    }

    public static void checkLowerCase() throws InterruptedException {
        login.clickLowerCase();
        Thread.sleep(1000);
        if (dashboard.getHeading().toString().equalsIgnoreCase("What's New"))
            test.log(LogStatus.PASS, "TC 6-Login with username in Lower Case: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 6-Login with username in Lower Case: FAILED");
        dashboard.clickLogout();
    }

    public static void checkUpperLowerCase() throws InterruptedException {
        login.clickUpperLowerCase();
        Thread.sleep(1000);
        if (dashboard.getHeading().toString().equalsIgnoreCase("What's New"))
            test.log(LogStatus.PASS, "TC 7-Login with username in Upper and Lower Case: PASSED");
        else
            test.log(LogStatus.FAIL, "TC 7-Login with username in Upper and Lower Case: FAILED");
    }


    public static void checkChatHistoryReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.chatHistoryReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickChatHistoryReport().toString().equalsIgnoreCase("Chat History"))
                test.log(LogStatus.PASS, "TC 8-Chat History Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 8-Chat History Report check: FAILED");
        }
        else {
            reportPageObject.goToChatReport();
            checkChatHistoryReport();
        }
    }

    public static void checkOfflineMessageReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.offlineMessageReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickOfflineMessageReport().toString().equalsIgnoreCase("Offline Message"))
                test.log(LogStatus.PASS, "TC 9-Offline Message Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 9-Offline Message Report check: FAILED");
        }
        else {
            reportPageObject.goToChatReport();
            checkOfflineMessageReport();
        }
    }

    public static void checkMissedChatsReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.missedChatsReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickMissedChatsReport().toString().equalsIgnoreCase("Missed Chat History"))
                test.log(LogStatus.PASS, "TC 10-Missed Chats Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 10-Missed Chats Report check: FAILED");
        }
        else {
            reportPageObject.goToChatReport();
            checkMissedChatsReport();
        }
    }


    public static void checkBotHistoryReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.botHistoryReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickBotHistoryReport().toString().equalsIgnoreCase("Bot History"))
                test.log(LogStatus.PASS, "TC 11-Bot History Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 11-Both History Report check: FAILED");
        }
        else {
            reportPageObject.goToBotReports();
            checkBotHistoryReport();
        }
    }

    public static void checkBotAnalyticsReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.botAnalyticsReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickBotAnalyticsReport().toString().equalsIgnoreCase("Bot Analytics"))
                test.log(LogStatus.PASS, "TC 12-Bot Analytics Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 12-Bot Analytics Report check: FAILED");
        }
        else {
            reportPageObject.goToBotReports();
            checkBotAnalyticsReport();
        }
    }

    public static void checkBotLeadReport() throws InterruptedException {
        if(driver.findElement(reportPageObject.botLeadReport).isDisplayed()) {
            Thread.sleep(1000);
            if(reportPageObject.clickBotLeadReport().toString().equalsIgnoreCase("Bot Lead Report"))
                test.log(LogStatus.PASS, "TC 13-Bot Lead Report check: PASSED");
            else
                test.log(LogStatus.FAIL, "TC 13-Bot Lead Report check: FAILED");
        }
        else {
            reportPageObject.goToBotReports();
            checkBotLeadReport();
        }
    }


    public static void endTest() {
        report.endTest(test);
        driver.close();
        driver.quit();
        report.flush();
    }
}
