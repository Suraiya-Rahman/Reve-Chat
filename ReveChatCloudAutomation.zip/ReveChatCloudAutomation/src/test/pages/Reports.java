package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static java.util.concurrent.TimeUnit.SECONDS;

public class Reports {

    WebDriver driver;

    public Reports(WebDriver driver) {
        // TODO Auto-generated constructor stub
        this.driver = driver;
    }

    By reportPage = By.xpath("//ul/li[3]/a[@data-href='#reports/summary']");
    By chats = By.xpath("//ul/li[2]/div/a/i[@class='icon-chats']");
    By botReport = By.xpath("//ul/li[4]/div/a/i[@class='icon-chat-bot']");


    public By chatHistoryReport = By.xpath("//ul[3]/li[2]/ul/li/a[@data-href='#reports/chat-history']");
    By chatHistoryReportHeading = By.xpath("//div[@class='report-title-option']/h5");

    public By offlineMessageReport = By.xpath("//ul[3]/li[2]/ul/li/a[@data-href='#reports/offline']");
    By offlineMessageReportHeading = By.xpath("//div[@class='report-title-option']/h5");

    public By missedChatsReport = By.xpath("//ul[3]/li[2]/ul/li/a[@data-href='#reports/details-missed-chats']");
    By missedChatsReportHeading = By.xpath("//div[@class='report-title-option col-md-6']/h5");
    public By botHistoryReport = By.xpath("//li[4]/ul/li/a[@data-href='#reports/bot-history']");
    By botHistoryReportHeading = By.xpath("//div[@class='report-title-option']");

    public By botAnalyticsReport = By.xpath("//li[4]/ul/li/a[@data-href='#reports/bot-analytics']");
    By botAnalyticsReportHeading = By.xpath("//div[@class='row']/h4");

    public By botLeadReport = By.xpath("//li[4]/ul/li/a[@data-href='#reports/bot-lead-info']");
    By botLeadReportHeading = By.xpath("//div[@class='report-title-option']/h5");



    public void goToChatReport() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(reportPage).click();
        driver.findElement(chats).click();
    }

    public String clickChatHistoryReport() {
        driver.findElement(chatHistoryReport).click();
        return driver.findElement(chatHistoryReportHeading).getText();
    }

    public String clickOfflineMessageReport() {
        driver.findElement(offlineMessageReport).click();
        return driver.findElement(offlineMessageReportHeading).getText();
    }

    public String clickMissedChatsReport() {
        driver.findElement(missedChatsReport).click();
        return driver.findElement(missedChatsReportHeading).getText();
    }


    public void goToBotReports() throws InterruptedException {
        driver.findElement(reportPage).click();
        Thread.sleep(2000);
        driver.findElement(botReport).click();
    }

    public String clickBotHistoryReport() throws InterruptedException{
        Thread.sleep(3000);
        driver.findElement(botHistoryReport).click();
        return driver.findElement(botHistoryReportHeading).getText();
    }

    public String clickBotAnalyticsReport() {
        driver.findElement(botAnalyticsReport).click();
        return driver.findElement(botAnalyticsReportHeading).getText();
    }

    public String clickBotLeadReport() {
        driver.findElement(botLeadReport).click();
        return driver.findElement(botLeadReportHeading).getText();
    }

}
