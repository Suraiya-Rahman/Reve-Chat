package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.Scanner;
import java.util.Random;


public class LoginPage {

    WebDriver driver;
    Scanner input = new Scanner(System.in);
    Random ran = new Random();

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    //Locator for username field
    // By uName = By.id("userName");

    By uName = By.xpath("//*[@id=\"loginForm\"]/div[1]/input");


    //Locator for password field
    By pswd = By.id("password");

    By loginBtn = By.id("intro-singup");


//    //Method to enter username
//    public void enterUsername(String user) {
//        //driver.findElement(uName).sendKeys(user);
//        driver.findElement(uName).sendKeys("revesqa2@yahoo.com");
//
//    }
//
//    //Method to enter password
//    public void enterPassword(String pass) {
//        // driver.findElement(pswd).sendKeys(pass);
//        driver.findElement(pswd).sendKeys("123456");
//    }

    //Method to click on Login button
    public void clickLoginWithValidCredentials() {
        driver.findElement(uName).sendKeys("xyz@zyz.xyz");
        driver.findElement(pswd).sendKeys("123456");
        driver.findElement(loginBtn).click();
    }

    public void clickLoginWithValidUserInvalidPassword() {
        driver.findElement(uName).sendKeys("mahi@gmail.com");
        driver.findElement(pswd).sendKeys("abcdefg");
        driver.findElement(loginBtn).click();
    }


    public void clickLoginWithInValidUserValidPassword() {
        driver.findElement(uName).sendKeys("invalidrevesqa3@yahoo.com");
        driver.findElement(pswd).sendKeys("123456");
        driver.findElement(loginBtn).click();
    }

    public void clickLoginWithInValidUserInvalidPassword() {
        driver.findElement(uName).sendKeys("invalidrevesqa3@yahoo.com");
        driver.findElement(pswd).sendKeys("abcdefg");
        driver.findElement(loginBtn).click();
    }

    public void clickUpperCase() {
        System.out.println("Input username for TC 5 (Upper Case check)");
        String userName = input.nextLine().toUpperCase();
        System.out.println("Username is " + userName);
        driver.findElement(uName).sendKeys(userName);
        driver.findElement(pswd).sendKeys("123456");
        driver.findElement(loginBtn).click();
        //input.close();
    }

    public void clickLowerCase() {
        System.out.println("Input username for TC 6 (Lower Case check)");
        String userName = input.nextLine().toLowerCase();
        System.out.println("Username is " + userName);
        driver.findElement(uName).sendKeys(userName);
        driver.findElement(pswd).sendKeys("123456");
        driver.findElement(loginBtn).click();
        //input.close();
    }

    public void clickUpperLowerCase() {
        System.out.println("Input username for TC 7 (Upper and Lower Case check)");
        String userName = input.nextLine();
        String[] arrName = userName.split("");
        for(int i = 0; i < arrName.length; i++) {
            int arrIndex = ran.nextInt(arrName.length);
            arrName[arrIndex] = arrName[arrIndex].toUpperCase();
        }
        userName = String.join("", arrName);
        System.out.println("Username is " + userName);
        driver.findElement(uName).sendKeys(userName);
        driver.findElement(pswd).sendKeys("123456");
        driver.findElement(loginBtn).click();
        input.close();
    }




    public String getLoginErrorMessage() {
        String loginError = driver.findElement(By.id("invalid_error")).getText();
        return loginError;
    }

    public String checkPasswordValueIsMasked() {
        return driver.findElement(pswd).getAttribute("type");
    }
}